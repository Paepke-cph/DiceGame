package net;

public class UserDisconnectedException extends Exception {

    public UserDisconnectedException() {
    }
}
